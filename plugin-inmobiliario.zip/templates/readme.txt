=== Plugin Inmobiliario ===
Contributors: codwelt
Tags: inmobiliaria, inmuebles, propiedades, real estate
Requires at least: 5.8
Tested up to: 6.7
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Descripción corta en 1–2 líneas, clara y directa.

== Description ==

Descripción larga, beneficios, características, ejemplos.

== Installation ==

1. Sube el plugin a `/wp-content/plugins/`.
2. Activa el plugin desde “Plugins”.
3. Configura las opciones en el menú “Inmobiliario”.

== Frequently Asked Questions ==

= ¿Pregunta? =
Respuesta.

== Changelog ==

= 1.0.0 =
* Versión inicial.

== Screenshots ==

1. Página de listado de inmuebles.
2. Página de detalles.
